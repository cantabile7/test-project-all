package com.example.cantabile.blowcandle;

import android.app.admin.DeviceAdminReceiver;

public class MyReceiver extends DeviceAdminReceiver {
}
