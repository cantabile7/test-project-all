package mytest.newsreader.bean;

import android.graphics.Bitmap;

import java.io.Serializable;

public class NewsBean implements Serializable {
	public String title;  
	public String link;
	public String description;
	public String pubDate;
	public String guid;
	public String icon;   //新增的新闻图片

}
